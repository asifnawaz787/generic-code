﻿using Microsoft.AspNetCore.Builder;
using WebApplication5.MiddleWare;

namespace WebApplication5
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection service)
        {
            var serviceProvider = service.BuildServiceProvider();
            var logger = serviceProvider.GetService<ILogger<ExceptionMiddleWare>>();
            service.AddSingleton(typeof(ILogger), logger);
            service.AddHealthChecks();
            service.AddMvc();
        }
        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
            if (env.IsDevelopment())
            {
                app.UseExceptionMiddleWare();

            }

            //app.Map("/map1",LoadP1);
            //app.Map("/map2", LoadP2);

            //app.MapWhen(context => context.Request.Query.ContainsKey("map3"), LoadP1);
            //app.UseWhen(context => context.Request.Query.ContainsKey("map4"), appBuilder => LoadP1(appBuilder));
            //app.Run(async context =>
            //{
            //    await context.Response.WriteAsync("Hello World Welcome");
                
            //});
            app.UseRouting();
            //app.UseExtenstionMiddleware();
            //static void LoadP1(IApplicationBuilder  app)
            //{
            //    var logger = app.ApplicationServices.GetRequiredService<ILogger<Program>>();
            //    app.Run(async context =>
            //    {
            //        var bValue = context.Request.Query["map3"];
            //        logger.LogInformation(bValue);
                    
            //    });
            //}

            //static void LoadP2(IApplicationBuilder builder)
            //{
            //    builder.Run(async context => {
            //        await context.Response.WriteAsync("Hello P2");
            //    });
            //}
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
