﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace WebApplication5.MiddleWare
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class Middleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _loger;

        public Middleware(RequestDelegate next,ILogger loger)
        {
            _next = next;
            _loger = loger;
        }

        public Task Invoke(HttpContext httpContext)
        {
           
            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseExtenstionMiddleware(this IApplicationBuilder builder)
        {
            
            return builder.UseMiddleware<Middleware>();

        }
    }
}
