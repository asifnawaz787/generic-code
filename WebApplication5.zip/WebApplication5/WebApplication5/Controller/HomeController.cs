﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            throw new NotImplementedException();
            return View();
        }
    }
}
